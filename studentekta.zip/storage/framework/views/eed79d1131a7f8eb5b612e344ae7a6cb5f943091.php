<?php $__env->startSection('content'); ?>
<div class="br-pagetitle">
        <i class="icon ion-ios-home-outline"></i>
        <div>
          <h4>State Management</h4>
          <p class="mg-b-0">Do bigger things with Bracket plus, the responsive bootstrap 4 admin template.</p>
        </div>
		 <div class="pull-right">
           
                <a class="btn btn-success" href="<?php echo e(route('states.create')); ?>"> Create New State</a>            
        </div>
</div>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
<div class="br-pagebody">
        <div class="br-section-wrapper">
          <h6 class="br-section-label">State List</h6>
		  <div class="pull-right" style="text-align: end;">
           <h4>Total Count: <?php echo e($statescount); ?></h4>            
        </div>
		    <div class="form-layout form-layout-1">
			<form action="<?php echo e(route('states.index')); ?>" method="PUT">
			<?php echo csrf_field(); ?>
            <div class="row mg-b-30">
			<h4 class="br-section-label">Filter By:</h4>
		  
			
			<div class="col-xs-8 col-sm-8 col-md-8">
		        <div class="form-group">
                  <label class="form-control-label">Country: <span class="tx-danger">*</span></label>
                  <select class="form-control select2-show-search" name="country_search">
				  <option value="">Select</option>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
		    </div>
			<div class="col-xs-4 col-sm-4 col-md-4 text-center">
		            <input type="submit" class="btn btn-primary" value="Search" name="btn">
		    </div>
			
			</form>
			</div>
			</div>
			<br>
          <table id="datatable1" class="table display responsive nowrap">
		<thead>
		<tr>
            <th>No</th>
            <th>Name</th>
            <th>Country</th>
			<th>Status</th>
            <th>Action</th>
        </tr>
		</thead>
		<tbody>
		<?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <tr>
	        <td><?php echo e($loop->iteration); ?></td>
	        <td><?php echo e($state->name); ?></td>
	        <td><?php echo e($state->country->name); ?></td>
			<td><?php if($state->status=='1'): ?>
					<span class='text-success'>Active</span>
				<?php else: ?>
					<span class='text-danger'>Inactive</span>
				<?php endif; ?></td>
	        <td>
                <form action="<?php echo e(route('states.destroy',$state->id)); ?>" method="POST">
                    <a class="btn btn-info" href="<?php echo e(route('states.show',$state->id)); ?>">Show</a>
                  
                    <a class="btn btn-primary" href="<?php echo e(route('states.edit',$state->id)); ?>">Edit</a>
                   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                   
                    <button type="submit" class="btn btn-danger">Delete</button>
                   
                </form>
	        </td>
	    </tr>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
		</table>

          

        </div><!-- br-section-wrapper -->
      </div><!-- br-pagebody -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\studentekta\resources\views/states/index.blade.php ENDPATH**/ ?>