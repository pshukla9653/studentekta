<?php $__env->startSection('content'); ?>
<div class="br-pagetitle">
        <i class="icon ion-ios-home-outline"></i>
        <div>
          <h4>Competitive Exam Management</h4>
          <p class="mg-b-0">Do bigger things with Bracket plus, the responsive bootstrap 4 admin template.</p>
        </div>
		 <div class="pull-right">
           
                <a class="btn btn-success" href="<?php echo e(route('exams.create')); ?>"> Create New Competitive Exam</a>
               
        </div>
</div>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
<div class="br-pagebody">
        <div class="br-section-wrapper">
          <h6 class="br-section-label">Competitive Exam List</h6>
          <table id="datatable1" class="table display responsive nowrap">
		<thead>
		<tr>
            <th>No</th>
            <th>Name</th>
            <th>Status</th>
			<th>Created At</th>
			<th>Updated At</th>
			<th>Created By</th>
			<th>Updated By</th>
            <th>Action</th>
        </tr>
		</thead>
		<tbody>
		<?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <tr>
	        <td><?php echo e($loop->iteration); ?></td>
	        <td><?php echo e($exam->name); ?></td>
	        <td><?php if($exam->status=='1'): ?>
					<span class='text-success'>Active</span>
				<?php else: ?>
					<span class='text-danger'>Inactive</span>
				<?php endif; ?></td>
			<td><?php echo e($exam->created_at); ?></td>
			<td><?php echo e($exam->updated_at); ?></td>
			<td>
			<?php
			if($exam->createdby !=null){
				$user = json_decode($exam->createdby, true);
				echo $user["name"];
			}
			?>
			</td>
			<td><?php
			if($exam->updatedby !=null){
				$user = json_decode($exam->updatedby, true);
				echo $user["name"];
			}
			?></td>
	        <td>
                <form action="<?php echo e(route('exams.destroy',$exam->id)); ?>" method="POST">
                    <a class="btn btn-info" href="<?php echo e(route('exams.show',$exam->id)); ?>">Show</a>
                    
                    <a class="btn btn-primary" href="<?php echo e(route('exams.edit',$exam->id)); ?>">Edit</a>
                   


                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                   
                    <button type="submit" class="btn btn-danger">Delete</button>
                   
                </form>
	        </td>
	    </tr>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
		</table>

          

        </div><!-- br-section-wrapper -->
      </div><!-- br-pagebody -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\studentekta\resources\views/exams/index.blade.php ENDPATH**/ ?>