<?php $__env->startSection('content'); ?>
<div class="br-pagetitle">
        <i class="icon ion-ios-home-outline"></i>
        <div>
          <h2>Create New Role</h2>
          <p class="mg-b-0">Do bigger things with Bracket plus, the responsive bootstrap 4 admin template.</p>
        </div>
		 <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('roles.index')); ?>"> Back</a>
        </div>
      </div>

<?php if(count($errors) > 0): ?>
  <div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
       <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><?php echo e($error); ?></li>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>



<div class="br-pagebody">
        <div class="br-section-wrapper">
          <h6 class="br-section-label">Create Role</h6>
         

          <div class="form-layout form-layout-1">
		 <?php echo Form::open(array('route' => 'roles.store','method'=>'POST')); ?>

            <div class="row mg-b-25">
              <div class="col-lg-4">
                <div class="form-group">
                  <label class="form-control-label">Name: <span class="tx-danger">*</span></label>
                  <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

                </div>
              </div><!-- col-4 -->
              
              <div class="col-lg-4">
                <div class="form-group">
            <strong>Permission:</strong>
            <br/>
            <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label><?php echo e(Form::checkbox('permission[]', $value->id, false, array('class' => 'name'))); ?>

                <?php echo e($value->name); ?></label>
            <br/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
              </div><!-- col-4 -->
             
             
            </div><!-- row -->

            <div class="form-layout-footer">
              <button class="btn btn-info">Submit</button>
            </div><!-- form-layout-footer -->
			
          </div><!-- form-layout -->

<?php echo Form::close(); ?>

        </div><!-- br-section-wrapper -->
      </div><!-- br-pagebody -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\studentekta\resources\views/roles/create.blade.php ENDPATH**/ ?>