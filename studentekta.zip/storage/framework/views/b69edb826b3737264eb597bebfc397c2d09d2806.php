<?php $__env->startSection('content'); ?>
<div class="br-pagetitle">
        <i class="icon ion-ios-home-outline"></i>
        <div>
          <h4>Location Management</h4>
          <p class="mg-b-0">Do bigger things with Bracket plus, the responsive bootstrap 4 admin template.</p>
        </div>
		 <div class="pull-right">
           
                <a class="btn btn-success" href="#" data-toggle="modal" data-target="#modaldemo1" data-effect="effect-newspaper"> Create New city</a> 
				<a class="btn btn-success" href="#" data-toggle="modal" data-target="#modaldemo2" data-effect="effect-newspaper"> Create New Villege</a>            
        </div>
</div>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
<?php if($message = Session::get('error')): ?>
    <div class="alert alert-danger">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
<div class="br-pagebody">
        <div class="br-section-wrapper">
          <h6 class="br-section-label">Location List</h6>
		  <div class="pull-right" style="text-align: end;">
           <h4>Total Count: <?php echo e($data['count']); ?></h4>            
        </div>
		  <div class="form-layout form-layout-1">
		  <form action="<?php echo e(route('locations.index')); ?>" method="PUT">
			<?php echo csrf_field(); ?>
			
            <div class="row mg-b-25">
             <h4 class="br-section-label">Filter By:</h4>
		  
              <div class="col-lg-3">
                <div class="form-group mg-b-10-force">
                  <label class="form-control-label">Country: <span class="tx-danger">*</span></label>
                  <select class="form-control select2-show-search" id="country-dd" name="country_search">
				  <option value="">Select</option>
                   <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($country->country_id); ?>"><?php echo e($country->country_name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div><!-- col-4 -->
			  
			  <div class="col-lg-3">
                <div class="form-group mg-b-10-force">
                  <label class="form-control-label">State: <span class="tx-danger">*</span></label>
                  <select class="form-control select2-show-search" data-placeholder="Choose state" id="state-dd" name="state_search">
                    
                  </select>
                </div>
              </div><!-- col-4 -->
			  <div class="col-lg-3">
                <div class="form-group mg-b-10-force">
                  <label class="form-control-label">City: <span class="tx-danger">*</span></label>
                  <select class="form-control select2-show-search" data-placeholder="Choose city" id="city-dd" name="city_search">
                    
                  </select>
				  
                </div>
              </div>
            </div><!-- row -->
			
            <div class="form-layout-footer">
              <input type="submit" class="btn btn-primary" value="Search" name="btn">
              
            </div><!-- form-layout-footer -->
			</form>
          </div><!-- form-layout -->
			<br>
		<?php if($datadisplay =='state'): ?>	
          <table id="datatable1" class="table display responsive nowrap">
		<thead>
		<tr>
            <th>No</th>
			<th>State</th>
            <th>Country</th>
			
			<th>Status</th>
			<th>Created At</th>
			<th>Updated At</th>
            
        </tr>
		</thead>
		<tbody>
		<?php $__currentLoopData = $data['states']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <tr>
	        <td><?php echo e($loop->iteration); ?></td>
			<td><?php echo e($state->state_name); ?></td>
	        <td><?php echo e($state->country_name); ?></td>
			
			
			<td><?php if($state->status=='1'): ?>
					<span class='text-success'>Active</span>
				<?php else: ?>
					<span class='text-danger'>Inactive</span>
				<?php endif; ?></td>
			<td><?php echo e($state->created_at); ?></td>
			<td><?php echo e($state->updated_at); ?></td>	
	        
	    </tr>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
		</table>
		<?php endif; ?>

		
			
		<?php if($datadisplay =='city'): ?>	
          <table id="datatable1" class="table display responsive nowrap">
		<thead>
		<tr>
            <th>No</th>
			<th>City</th>
			<th>State</th>
            <th>Country</th>
			<th>Status</th>
			<th>Created At</th>
			<th>Updated At</th>
            
        </tr>
		</thead>
		<tbody>
		<?php $__currentLoopData = $data['cities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <tr>
	        <td><?php echo e($loop->iteration); ?></td>
	        
	       
			<td><?php echo e($city['name']); ?></td>
			 
			<td><?php echo e($data['state_name']); ?></td>
			<td><?php echo e($data['country_name']); ?></td>
			<td><?php if($data['status']=='1'): ?>
					<span class='text-success'>Active</span>
				<?php else: ?>
					<span class='text-danger'>Inactive</span>
				<?php endif; ?></td>
			<td><?php echo e($data['created_at']); ?></td>
			<td><?php echo e($data['updated_at']); ?></td>	
	        
	    </tr>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
		</table>
		<?php endif; ?>
          
		<?php if($datadisplay =='villege'): ?>	
          <table id="datatable1" class="table display responsive nowrap">
		<thead>
		<tr>
            <th>No</th>
			<th>Villege</th>
			<th>City</th>
			<th>State</th>
            <th>Country</th>
			<th>Status</th>
			<th>Created At</th>
			<th>Updated At</th>
            
        </tr>
		</thead>
		<tbody>
		<?php $__currentLoopData = $data['villeges']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $villege): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <tr>
	        <td><?php echo e($loop->iteration); ?></td>
	        
			<td><?php echo e($villege['name']); ?></td>
			<td><?php echo e($data['city_name']); ?></td>
			 
			<td><?php echo e($data['state_name']); ?></td>
			<td><?php echo e($data['country_name']); ?></td>
			<td><?php if($data['status']=='1'): ?>
					<span class='text-success'>Active</span>
				<?php else: ?>
					<span class='text-danger'>Inactive</span>
				<?php endif; ?></td>
			<td><?php echo e($data['created_at']); ?></td>
			<td><?php echo e($data['updated_at']); ?></td>	
	        
	    </tr>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
		</table>
		<?php endif; ?>
        </div><!-- br-section-wrapper -->
      </div><!-- br-pagebody -->
	  
	  
	  
	  <!-- CITY MODAL -->
          <div id="modaldemo1" class="modal fade effect-newspaper" style="overflow:hidden;">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content bd-0 tx-14">
                <div class="modal-header pd-y-20 pd-x-25">
                  <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Add City</h6>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <div class="">
		  <form action="<?php echo e(route('add-city')); ?>" method="POST">
			<?php echo csrf_field(); ?>
			
            <div class="row">
            
		  
              <div class="col-lg-12">
                <div class="form-group">
                  <label class="form-control-label">Country: <span class="tx-danger">*</span></label>
                  <select class="form-control select2-show-search" id="country-city" name="country_id">
				  <option value="">Select</option>
                   <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($country->country_id); ?>"><?php echo e($country->country_name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div><!-- col-4 -->
			  
			  <div class="col-lg-12">
                <div class="form-group">
                  <label class="form-control-label">State: <span class="tx-danger">*</span></label>
                  <select class="form-control select2-show-search" data-placeholder="Choose state" id="state-city" name="state_id">
                    
                  </select>
                </div>
              </div><!-- col-4 -->
			  <div class="col-lg-12">
                <div class="form-group">
                  <label class="form-control-label">City: <span class="tx-danger">*</span></label>
                  <input type="text" class="form-control" name="city_name"/>
                </div>
              </div>
            </div><!-- row -->

           
			
          </div><!-- form-layout -->
                </div>
                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium">Save</button>
                  <button type="button" class="btn btn-secondary tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium" data-dismiss="modal">Close</button>
                </div>
				</form>
              </div>
            </div><!-- modal-dialog -->
          </div><!-- modal -->
		  
		  <!-- VILLEGE MODAL -->
          <div id="modaldemo2" class="modal fade effect-newspaper" style="overflow:hidden;">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content bd-0 tx-14">
                <div class="modal-header pd-y-20 pd-x-25">
                  <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Add Villege</h6>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <div class="">
		  <form action="<?php echo e(route('add-villege')); ?>" method="POST">
			<?php echo csrf_field(); ?>
			
            <div class="row">
            
		  
              <div class="col-lg-12">
                <div class="form-group">
                  <label class="form-control-label">Country: <span class="tx-danger">*</span></label>
                  <select class="form-control select2-show-search" id="country-villege" name="country_id">
				  <option value="">Select</option>
                   <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($country->country_id); ?>"><?php echo e($country->country_name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div><!-- col-4 -->
			  
			  <div class="col-lg-12">
                <div class="form-group">
                  <label class="form-control-label">State: <span class="tx-danger">*</span></label>
                  <select class="form-control select2-show-search" data-placeholder="Choose state" id="state-villege" name="state_id">
                    
                  </select>
                </div>
              </div><!-- col-4 -->
			  <div class="col-lg-12">
                <div class="form-group">
                  <label class="form-control-label">City: <span class="tx-danger">*</span></label>
                  <select class="form-control select2-show-search" data-placeholder="Choose city" id="city-villege" name="city_id">
                    
                  </select>
                </div>
              </div>
			  <div class="col-lg-12">
                <div class="form-group">
                  <label class="form-control-label">Villege: <span class="tx-danger">*</span></label>
                  <input type="text" class="form-control" name="villege_name"/>
                </div>
              </div>
            </div><!-- row -->

            
			
          </div><!-- form-layout -->
                </div>
                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium">Save</button>
                  <button type="button" class="btn btn-secondary tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium" data-dismiss="modal">Close</button>
                </div>
				</form>
              </div>
            </div><!-- modal-dialog -->
          </div><!-- modal -->
	  <script>
        $(document).ready(function () {
            $('#country-dd').on('change', function () {
                var idCountry = this.value;
                $('#state-dd').html('<option value="">Select State</option>');
                $.ajax({
                    url: "<?php echo e(url('api/fetch-states')); ?>",
                    type: "POST",
                    data: {
                        country_id: idCountry,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function (result) {
                        $('#state-dd').html('<option value="">Select State</option>');
                        $.each(result.states, function (key, value) {
                            $("#state-dd").append('<option value="' + value
                                .id + '">' + value.state_name + '</option>');
                        });

                    }
                });
            });
			
			$('#state-dd').on('change', function () {
                var idState = this.value;
                
                $.ajax({
                    url: "<?php echo e(url('api/fetch-cities')); ?>",
                    type: "POST",
                    data: {
                        state_id: idState,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function (result) {
						if(result.cities ==null){
							$('#city-dd').html('<option value="">No City Found</option>');
						}
						else{
                        $('#city-dd').html('<option value="">Select City</option>');
                        $.each(result.cities, function (key, value) {
                            $("#city-dd").append('<option value="' + value
                                .id + '">' + value.name + '</option>');
                        });
						}
                    },
					
                });
            });
			
			$('#country-city').on('change', function () {
                var idCountry = this.value;
                $('#state-city').html('<option value="">Select State</option>');
                $.ajax({
                    url: "<?php echo e(url('api/fetch-states')); ?>",
                    type: "POST",
                    data: {
                        country_id: idCountry,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function (result) {
                        $('#state-city').html('<option value="">Select State</option>');
                        $.each(result.states, function (key, value) {
                            $("#state-city").append('<option value="' + value
                                .id + '">' + value.state_name + '</option>');
                        });

                    }
                });
            });
			$('#country-villege').on('change', function () {
                var idCountry = this.value;
                $('#state-villege').html('<option value="">Select State</option>');
                $.ajax({
                    url: "<?php echo e(url('api/fetch-states')); ?>",
                    type: "POST",
                    data: {
                        country_id: idCountry,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function (result) {
                        $('#state-villege').html('<option value="">Select State</option>');
                        $.each(result.states, function (key, value) {
                            $("#state-villege").append('<option value="' + value
                                .id + '">' + value.state_name + '</option>');
                        });

                    }
                });
            });
			
			$('#state-villege').on('change', function () {
                var idState = this.value;
                
                $.ajax({
                    url: "<?php echo e(url('api/fetch-cities')); ?>",
                    type: "POST",
                    data: {
                        state_id: idState,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function (result) {
						if(result.cities ==null){
							$('#city-villege').html('<option value="">No City Found</option>');
						}
						else{
                        $('#city-villege').html('<option value="">Select City</option>');
                        $.each(result.cities, function (key, value) {
                            $("#city-villege").append('<option value="' + value
                                .id + '">' + value.name + '</option>');
                        });
						}
                    },
					
                });
            });
			
            });
       
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\studentekta\resources\views/locations/index.blade.php ENDPATH**/ ?>